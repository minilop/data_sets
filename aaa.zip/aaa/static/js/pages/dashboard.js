/*
 * Author: Abdullah A Almsaeed
 * Date: 4 Jan 2014
 * Description:
 *      This is a demo file used only for the main dashboard (index.html)
 **/

/* global moment:false, Chart:false, Sparkline:false */

$(function () {
  'use strict'

  // Make the dashboard widgets sortable Using jquery UI
  $('.connectedSortable').sortable({
    placeholder: 'sort-highlight',
    connectWith: '.connectedSortable',
    handle: '.card-header, .nav-tabs',
    forcePlaceholderSize: true,
    zIndex: 999999
  })
  $('.connectedSortable .card-header').css('cursor', 'move')


  // nav
  $(".nav .nav-link").click(function(){
    var page = $(this).attr("page")
    if(typeof(page) != 'undefined'){
      page = page+"?"+(new Date()).getTime()
      $('.active').removeClass('active')
      $(this).addClass("active")

      if($(this).parent().parent().hasClass('nav-treeview')){
        $(this).parent().parent().parent().find('a:first').addClass('active')
      }

      $.get(page, function(rs){
        $(".content-wrapper").html(rs)
      },'html')
    }
  })

  // -----------------
  // --global search--
  // -----------------
  $('#global-search').keyup(function(event){
    if(event.keyCode === 13){
      var value = $('#global-search').val()
      $.get('/pages/search_result.html', function(rs){
        $('#search-result').html(rs)
        $('#search-modal').modal('show')
      })
    }
    if(event.keyCode == 27){
      $('#search-close').click()
    }
  })

  // project per month
  var bar_data = {
    data : [[6,10], [7,15], [8,11], [9,24], [10,12], [11,30]],
    bars: { show: true }
  }
  $.plot('#project-chart', [bar_data], {
    grid  : {
      borderWidth: 1,
      borderColor: '#f3f3f3',
      tickColor  : '#f3f3f3'
    },
    series: {
       bars: {
        show: true, barWidth: 0.5, align: 'center',
      },
    },
    colors: ['#006bff'],
    xaxis : {
      ticks: [[6,'6月'], [7,'7月'], [8,'8月'], [9,'9月'], [10,'10月'], [11,'11月']]
    }
  })
  /* END BAR CHART */

  //-------------
  //- DONUT CHART -
  //-------------
  var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
    var donutData = {
      labels: [
          'AWS',
          'javascript',
          'インフラ',
          'python',
          'C#',
          'java',
      ],
      datasets: [
        {
          data: [66,55,23,13,63,123],
          backgroundColor : ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#007bff'],
        }
      ]
    }
    var donutOptions = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(donutChartCanvas, {
      type: 'doughnut',
      data: donutData,
      options: donutOptions
    })
})

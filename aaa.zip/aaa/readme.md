https://ionicframework.com/docs/v3/ionicons/

file:///home/likai/%E4%B8%8B%E8%BD%BD/mfv34cfsedwcwwe/mfv34cfsedwcwwe/freelancer-detail.html
file:///home/likai/%E4%B8%8B%E8%BD%BD/mfv34cfsedwcwwe/mfv34cfsedwcwwe/half-map-list.html#

マッチング度

jianli
file:///home/likai/%E4%B8%8B%E8%BD%BD/AdminLTE-3.2.0/pages/examples/profile.html

file:///home/likai/%E4%B8%8B%E8%BD%BD/mfv34cfsedwcwwe/mfv34cfsedwcwwe/freelancer-detail.html

file:///home/likai/%E4%B8%8B%E8%BD%BD/dfj-20210410-5/candidates-profile.html

./configure \
--prefix=/home/likai/environment/nginx-1.24.0 \
--user=likai \
--group=likai \
--with-http_sub_module

make && make install


＃ ===================================

IoT系製品やソフトウェアの組込み開発案件(C・C++)

◆基本情報◆
・金額：スキル見合い
・年齢：60代まで
・国籍：外国籍可(コミュニケーションが取れる方)
・時期：即日 / 3月～
・出社：完全出社 ※週2～3日リモート相談可能の現場あり
・場所：新宿・品川・新横浜(選考段階で勤務地を決定します)
・期間：長期予定
・時間：9:00～18:00 ※常駐先により異なる
・服装：ビジネスカジュアル
・貸与：PC貸与あり(Windows)
・面談：2回

◆主な開発環境・ツール◆
・使用言語(FW):C++・C
・OS：Windows

◆必須スキル◆
・C・C＋＋を用いた開発経験3年以上
・設計のご経験
※直近開発に携わっていた方のみ

【業務内容】
携わる案件によって様々ですが、
主にはハードウェアに用いるソフトウェア設計を行なっていただきます。
現場メンバーと共に手を動かせる方が求められるので、直近での開発経験を必須とさせて頂いております。
・仕様定義
・詳細設計
・開発
・テスト etc.

【就業形態について】
基本は出社をお願いしておりますが、各現場によってはリモート併用な場合がございます。

# =======================================





上記の情報により、案件内容、募集人数、最大単金、日语レベル、経験年数、場所、リモート、期間、スキルを取得してください
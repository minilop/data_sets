from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
import uvicorn

app = FastAPI(debug=True)

# app.mount("/static", StaticFiles(directory="static"), name="static")

# @app.get('/', response_class=HTMLResponse)
# def index():
#     html = open('templates/index.html', 'r').read()
#     return html

# @app.post('/index/company', response_class=HTMLResponse)
# def get_company():
#     html = open('templates/pages/company.html', 'r').read()
#     return html

# @app.post('/index/engineer', response_class=HTMLResponse)
# def get_engineer():
#     html = open('templates/pages/engineer.html', 'r').read()
#     return html

# @app.post('/index/calendar', response_class=HTMLResponse)
# def get_calendar():
#     html = open('templates/pages/calendar.html', 'r').read()
#     return html

# @app.post('/index/personnel', response_class=HTMLResponse)
# def get_trade():
#     html = open('templates/pages/trade_personnel.html', 'r').read()
#     return html

# @app.post('/index/project', response_class=HTMLResponse)
# def get_project():
#     html = open('templates/pages/project.html', 'r').read()
#     return html

# @app.post('/recall', response_class=HTMLResponse)
# def get_recall():
#     html = open('templates/pages/recall.html', 'r').read()
#     return html

if __name__ == '__main__':
    uvicorn.run("main:app", port=8081,host="127.0.0.1", reload=True)